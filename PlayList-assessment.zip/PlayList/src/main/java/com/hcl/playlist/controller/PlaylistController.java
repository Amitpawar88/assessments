package com.hcl.playlist.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.playlist.entity.Playlist;
import com.hcl.playlist.service.PlaylistService;

@RestController
@RequestMapping("/v1/playlists")
public class PlaylistController {
	@Autowired
	private PlaylistService playlistService;
	
	@PostMapping("")
	public ResponseEntity<Playlist> createPlaylist(Playlist playlist) {
		return ResponseEntity.status(HttpStatus.CREATED).body(playlistService.createPlaylist(playlist));
	}
	
	@GetMapping("")
	public ResponseEntity<List<Playlist>> getAllPlaylist() {
		return ResponseEntity.status(HttpStatus.OK).body(playlistService.getAllPlaylist());
	}
	
	@GetMapping("/{playlistId}")
	public ResponseEntity<Playlist> getPlaylistById(@PathVariable Long playlistId) {
		return ResponseEntity.status(HttpStatus.OK).body(playlistService.getPlaylistById(playlistId));
	}
	
	@DeleteMapping("/{playlistId}")
	public ResponseEntity<?> deletePlaylistById(@PathVariable Long playlistId) {
		playlistService.deletePlaylistById(playlistId);
		return ResponseEntity.noContent().build();
	}
}
