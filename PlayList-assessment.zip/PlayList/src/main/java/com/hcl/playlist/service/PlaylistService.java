package com.hcl.playlist.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcl.playlist.entity.Playlist;
import com.hcl.playlist.repository.PlaylistRepository;

@Service
public class PlaylistService {
	@Autowired
	private PlaylistRepository playlistRepository;
	
	public Playlist createPlaylist(Playlist playlist) {
		return playlistRepository.save(playlist);
	}
	
	public List<Playlist> getAllPlaylist() {
		return playlistRepository.findAll();
	}

	public Playlist getPlaylistById(Long playlistId) {
		return playlistRepository.findById(playlistId).orElse(null);
	}

	public void deletePlaylistById(Long playlistId) {
		playlistRepository.deleteById(playlistId);
		return;
	}
}
