package com.hcl.playlist.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Playlist {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String name;
	private Integer trackCount;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getTrackCount() {
		return trackCount;
	}
	public void setTrackCount(Integer trackCount) {
		this.trackCount = trackCount;
	}
	public Playlist() {
		super();
	}
	@Override
	public String toString() {
		return "Playlist [id=" + id + ", name=" + name + ", trackCount=" + trackCount + "]";
	}
	
	
}
